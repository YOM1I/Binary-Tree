void Stablo::tekstulne_poruke_istorija() {
    niz = new Korisnik*[this->n];
    for (int i = 0; i < this->n; i++) {
        niz[i] = nullptr;
    }
}

void Stablo::posalji_poruku(string prezime ,string ime,  long long brtel) {
    Korisnik*temp = pronalazim_ako_postoji(prezime, ime, brtel);

    if(!temp) {
        cout << "Ne postoji trazeni konkat" << endl;
        return;
    }
    temp = izabrani_korisnik(temp, 1);
    Korisnik* novi = new Korisnik;
    novi->ime = temp->ime;
    novi->prezime = temp->prezime;
    novi->brtel = temp->brtel;

    temp = novi;

    int i = prodnaji_u_niz(temp);
    int j;
    Korisnik*vrijednost = nullptr;
    if(i == -1) {
        vrijednost = temp;
        j = this->n;
    }
    else {
        delete temp;
        vrijednost = niz[i];
        j = i;
    }
    for( ; j > 0; j--) {
        niz[j] = niz[j-1];
    }
    niz[0] = vrijednost;
}

int Stablo::prodnaji_u_niz(Korisnik *temp) {
    for(int i = 0; i < this->n; i++) {
        if(niz[i] != nullptr) {
            if(temp->brtel == niz[i]->brtel && temp->ime == niz[i]->ime  && temp->prezime == niz[i]->prezime) {
                return i;
            }
        }
    }
    return -1;
}

void Stablo::printaj_niz() {
    for(int i = 0; i < this->n; i++) {
        if(niz[i] != nullptr){
            cout << niz[i]->prezime << " "<< niz[i]->ime << " "<< niz[i]->brtel << " , ";
        }
        else {
            cout << "0" << " , ";
        }
    }
    cout << endl;
}

void Stablo::slanje_sadrzaja(string prezime, string ime, long long brtel) {
    Korisnik*temp = pronalazim_ako_postoji(prezime, ime, brtel);
    if(!temp) {
        cout << "Ne postoji trazeni konkat" << endl;
        return;
    }
    temp = izabrani_korisnik(temp, 1);

    Korisnik* novi = new Korisnik;
    novi->ime = temp->ime;
    novi->prezime = temp->prezime;
    novi->brtel = temp->brtel;
    novi->komunikacija = 0;

    temp = novi;

    if(!this->head) {
        head = temp;
        tail = temp;
        temp->komunikacija++;

    }
    else {
        int k = pronadji_u_listi(temp);
        if(k == 0) {
            Korisnik*pomocni = nadji(temp);
            pomocni->komunikacija++;
            delete temp;
            return;
        }
        else if(k == -1) {
            tail->next = temp;
            temp->prev = tail;
            tail = temp;
            temp->komunikacija++;
        }

        else {
            Korisnik*pomocni = nadji(temp);
            delete temp;
            temp = pomocni;

            if(temp->komunikacija >= this->x && temp != this->head) {
                Korisnik*p = temp->prev;
                Korisnik*j = head->next;
                if(head->next == temp) {
                    string prz = temp->prezime;
                    string im = temp->ime;
                    long long tel = temp->brtel;

                    temp->prezime = head->prezime;
                    temp->ime = head->ime;
                    temp->brtel = head->brtel;

                    head->prezime = prz;
                    head->ime = im;
                    head->brtel = tel;
                    cout << "BLAAAAA" << endl;
                }

                else {
                    temp->prev = this->head->prev;
                    this->head->next = temp->next;
                    if(temp->next != nullptr) {
                        temp->next->prev= this->head;
                    }
                    this->head->prev = p;
                    p->next = this->head;
                    temp->next = j;
                    j->prev = temp;
                    this->head = temp;
                }
            }
            else if(temp->komunikacija < this->x && temp != this->head){
                Korisnik*q = temp->prev;
                q->next = temp->next;
                if(temp->next != nullptr) {
                    temp->next->prev = q;
                }
                if(q->prev != nullptr) {
                    q->prev->next = temp;
                }
                temp->prev = q->prev;
                temp->next = q;
                q->prev = temp;
                if(temp == tail) {
                    tail = q;
                }
                if(q == head) {
                    head = temp;
                }

            }
            temp->komunikacija++;

        }
    }
}

int Stablo::pronadji_u_listi(Korisnik *temp) {
    if(this->head == temp) {
        return 0;
    }
    Korisnik*copy_head = this->head;
    while(copy_head) {
        if(copy_head->brtel == temp->brtel && temp->ime == copy_head->ime  && temp->prezime == copy_head->prezime) {
            //cout << "PRONASAO";
            return 1;
        }
        copy_head = copy_head->next;
    }
    return -1;
}

void Stablo::ispis_liste() {
    Korisnik*temp = this->head;
    if(this->head ==nullptr) {
        return;
    }
    for(; temp!= nullptr; temp = temp->next) {
        cout<< temp->prezime << " " << temp->ime << " " << temp->brtel << " -> ";
    }
    cout <<endl;
}

Stablo::Korisnik * Stablo::nadji(Korisnik *temp) {
    Korisnik*pomocni = this->head;
    for(; pomocni!= nullptr; pomocni = pomocni->next) {
        if(pomocni->brtel == temp->brtel) return pomocni;
    }
}